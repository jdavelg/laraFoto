<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <?php if(session('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session('message')); ?>

            </div>
            <?php endif; ?>





            <div class="card">
                <div class="card-header">
                    <?php if($image->user->image): ?>
                    <div style="display: block;">
                        <a class="navbar-brand" style="padding-top: 10px; float: left; line-height: 0px"  href="#">
                            <img   src="<?php echo e(route('user.avatar',['filename'=>$image->user->image])); ?>"  class="rounded-circle" width="25px"  alt="auto">
                        </a>
                    </div>
                    <?php endif; ?>
                    <div class="container" style="line-height: 35px; font-weight: bold">
                        <a href="<?php echo e(route('profile',['id'=>$image->user->id])); ?>"> <?php echo e($image->user->name.' '. $image->user->surname); ?></a>
                        <span style="color: #6f1C00; font-style: italic"> <?php echo e('@'.$image->user->nick); ?></span>
                    </div>

                </div>

                <div class="card-body">
                    <div class="image-container">
                        <img class="img-fluid" src="<?php echo e(route('image.file',['filename'=>$image->image_path])); ?>"/>
                    </div>
                </div>

                <div class="description">
                    <span style="color: #6f1C00; font-style: italic" class="nickname"><?php echo e('@'.$image->user->nick); ?></span>   
                    <span style="color: black; font-style: italic" class="nickname"><?php echo e(\Carbon\Carbon::now()->diffForHumans($image->create_at)); ?></span>
                    <p><?php echo e($image->description); ?></p>
                </div>
                <div class="row likeand">
                    <div class="likes">

                        <?php $user_like = false; ?>
                        <!--                        comprobar si existe el like-->
                        <?php $__currentLoopData = $image->likes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $like): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($like->user->id== Auth::user()->id): ?>
                        <?php $user_like = true; ?>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php if($user_like): ?>
                        <img src="<?php echo e(asset('img/rojo.png')); ?>" data-id="<?php echo e($image->id); ?>" class="btn-dislike">
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/gray.png')); ?>" data-id="<?php echo e($image->id); ?>" class="btn-like">
                        <?php endif; ?>
                        <span class="number_likes"><?php echo e(count($image->likes)); ?></span>

                    </div>
                    <?php if(Auth::user() && Auth::user()->id== $image->user->id): ?>
                    <div class="actions">
                        <a href="<?php echo e(route('image.edit',['id'=>$image->id])); ?>"  class="btn btn-sm btn-primary">Actualizar</a>    
                         
                        <button type="button" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#exampleModalCenter">
  Eliminar
</button>

<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
          <h5 class="modal-title" style="text-align: center" id="exampleModalLongTitle">Eliminar </h5>
        
          <span aria-hidden="true"></span>
        </button>
      </div>
      <div class="modal-body">
       realmente desea eliminar la imagen? esta accion no se puede deshacer..
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
        <a href="<?php echo e(route('image.delete',['id'=> $image->id])); ?>"  class="btn btn-danger">Eliminar</a>
      </div>
    </div>
  </div>
</div>
                    </div>
                    <?php endif; ?>
                </div>

                <div class="clearfix"></div>
                <br>
                <div class="comentarios" style="margin-left: 45px">

                    <h2>comentarios (<?php echo e(count($image->comments)); ?>)</h2>
                    <hr>
                    <div class="row">
                        <form method="POST" action="<?php echo e(action('CommentController@save')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="image_id" value="<?php echo e($image->id); ?>"/>

                            <textarea style="width: 167%; resize: both;" class="border border-success"  name="content" placeholder="Comenta esta Foto" required >
                                
                            </textarea>

                            <input type="submit" style="margin-top: 3px"class="btn btn-success" value="enviar">


                        </form>
                    </div>


                    <br/>
                    <?php $__currentLoopData = $image->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="comment">

                        <span style=" font-style: italic" class="nickname"><?php echo e('@'.$comment->user->nick); ?></span>   
                        <span style="color: black; font-style: italic" class="nickname"><?php echo e(\Carbon\Carbon::now()->diffForHumans($comment->create_at)); ?></span>
                        <p><?php echo e($comment->content); ?><br/>
                            <?php if(Auth::check() && ($comment->user_id== Auth::user()->id|| $comment->image->user_id==Auth::user()->id )): ?>
                            <a href="<?php echo e(route('comment.delete',['id'=>$comment->id])); ?>" class="btn btn-sm btn-danger">Eliminar</a>
                        </p>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

            </div>


        </div>


    </div>

</div>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\proyecto-laravel\resources\views/image/detail.blade.php ENDPATH**/ ?>