<?php if(Auth::user()->image): ?>
                       
                            <img src="<?php echo e(route('user.avatar',['filename'=>Auth::user()->image])); ?>" class= "img-thumbnail" width="80px" />
                       
                        <?php endif; ?>
<?php /**PATH C:\wamp64\www\proyecto-laravel\resources\views/includes/avatar.blade.php ENDPATH**/ ?>