<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <?php if(session('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session('message')); ?>

            </div>
            <?php endif; ?>

            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



            <div class="card">
                <div class="card-header">
                    <?php if($image->user->image): ?>
                    <div style="display: block;">
                        <a class="navbar-brand" style="padding-top: 10px; float: left; line-height: 0px"  href="#">
                            <img  src="<?php echo e(route('user.avatar',['filename'=>$image->user->image])); ?>"  class="rounded-circle" width="25px"  alt="auto">
                        </a>
                    </div>
                    <?php endif; ?>
                    <div class="container" style="line-height: 35px; font-weight: bold">
                        <a style="color: black" href="<?php echo e(route('image.detail',['id'=>$image->id])); ?>">
                        <?php echo e($image->user->name.' '. $image->user->surname); ?>

                        <span style="color: #6f1C00; font-style: italic"> <?php echo e('@'.$image->user->nick); ?></span>
                        </a>
                    </div>

                </div>

                <div class="card-body">
                    <div class="image-container">
                        <img class="img-fluid" src="<?php echo e(route('image.file',['filename'=>$image->image_path])); ?>"/>
                    </div>
                </div>

                <div class="description">
                    
                    <span style="color: #6f1C00; font-style: italic" class="nickname"><?php echo e('@'.$image->user->nick.'  '); ?></span>  
                    <span style="color: black; font-style: italic" class="nickname"><?php echo e(\Carbon\Carbon::now()->diffForHumans($image->create_at)); ?></span>
                    <p><?php echo e($image->description); ?></p>
                </div>
                <div class="row likeand">
                <div class="likes">
                    <img src="<?php echo e(asset('img/gray.png')); ?>">
                </div>
                <div class="comments">
                    <a  href="" type="button" class="btn btn-sm btn-warning btn-comments">
                        comentarios (<?php echo e(count($image->comments)); ?>)
                    </a>
                </div>
                    </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!--paginacion-->
            <div class="clearfix pagination justify-content-center">
                <?php echo e($images->links()); ?>

            </div>
        </div>


    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\proyecto-laravel\resources\views//home.blade.php ENDPATH**/ ?>