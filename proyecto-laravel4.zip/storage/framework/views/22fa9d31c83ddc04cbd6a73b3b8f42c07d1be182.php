

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <h1 style="text-align: center; font-style: initial">Personas</h1>
            <br>
            <nav class="navbar navbar-light bg-light col-md-6">
                <form action="<?php echo e(route('user.index')); ?>" class="form-inline" method="GET" id="buscador">
                    <input class="form-control mr-sm-2"  id="search" type="search" placeholder="Buscar personas.." aria-label="Search">
                    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Buscar</button>
                </form>
            </nav>
            <br>
            <?php if(session('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session('message')); ?>

            </div>
            <?php endif; ?>

            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="data-user">

                <?php if($user->image): ?>
                <div class="col-md-4" style="display: block;">
                    <a class="navbar-brand" style="padding-top: 10px; float: left; line-height: 0px"  href="#">
                        <img  src="<?php echo e(route('user.avatar',['filename'=>$user->image])); ?>"  class="rounded-circle border border-info" width="100px"  height="100px" alt="auto">
                    </a>
                </div>
                <?php endif; ?>
            </div>

            <div class="col-md-8">
                <h2> <?php echo e('@'.$user->nick); ?></h2>  
                <h3><?php echo e($user->name.' '.$user->surname); ?></h3>
                <h4 style="font-style: italic; font-size: small"><?php echo e('Se unio a Larafoto '.\Carbon\Carbon::now()->diffForHumans($user->create_at)); ?></h4>
                <a href="<?php echo e(route('profile',['id'=>$user->id])); ?>" class="btn btn-success">Ver perfil</a>
            </div>
            <hr>
            <br>
            <br>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



            <!--paginacion-->
            <div class="clearfix pagination justify-content-center">
                <?php echo e($users->links()); ?>

            </div>
        </div>


    </div>

</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\proyecto-laravel\resources\views/user/index.blade.php ENDPATH**/ ?>